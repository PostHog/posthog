"""Shared httpx plumbing for the sync + async clients.

Centralises three things that would otherwise drift between
:class:`hogland.Hogland` and :class:`hogland.AsyncHogland`:

* Building the ``httpx.Client`` / ``AsyncClient`` with the same base
  URL, bearer header, and timeout policy.
* Normalising config lookup: ``HOG_HOST`` / ``HOG_TOKEN`` env vars,
  matching the hogland CLI (``pkg/cliconfig/cliconfig.go``).
* Mapping non-2xx responses to the typed exception tree in
  :mod:`hogland._errors`.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any

import httpx

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

from ._errors import APIError, ConfigurationError, from_status
from ._version import __version__

DEFAULT_BASE_URL = "https://hogland.posthog.dev"
DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0, read=30.0, write=30.0)


def resolve_base_url(base_url: str | None) -> str:
    """Resolve the API base URL from arg → env → default."""
    if base_url:
        return base_url.rstrip("/")
    env = os.environ.get("HOG_HOST")
    if env:
        return env.rstrip("/")
    return DEFAULT_BASE_URL


def resolve_token(token: str | None) -> str:
    """Resolve the bearer token from arg → env, raising if absent."""
    if token:
        return token
    env = os.environ.get("HOG_TOKEN")
    if env:
        return env
    msg = (
        "hogland: no API token provided. Pass token=... to the client "
        "or set HOG_TOKEN in the environment."
    )
    raise ConfigurationError(msg)


def default_headers(token: str) -> dict[str, str]:
    """Default request headers.

    ``Authorization: Bearer <token>`` is the wire format for *all*
    AUTH_PLAN paths — long-lived APIToken (Path 1), K8s ServiceAccount
    JWT verified cross-account via EKS OIDC (Path 3), and GitHub OIDC.
    Hogplane parses the credential and selects the resolution path
    server-side; the SDK is intentionally credential-agnostic.
    """
    return {
        "Authorization": f"Bearer {token}",
        "User-Agent": f"hogland-python/{__version__}",
        "Accept": "application/json",
    }


def _build_create_body(  # noqa: PLR0912, PLR0913, C901 — mirrors the BoxSpec wire shape
    *,
    cpus: float | None,
    memory_mib: int | None,
    disk_gib: int | None,
    disk_class: object | None,
    disk_mbps: int,
    disk_iops: int,
    net_mbps: float,
    access_type: object | None,
    snapshot_id: str | None,
    ssh_public_key: str | None,
    bootstrap: str | None,
    env: Mapping[str, str] | None,
    ttl_seconds: int | None,
    name: str | None,
    kind: str | None,
    tags: Sequence[str] | None,
    web_port: int | None = None,
) -> dict[str, Any]:
    """Build the create-box request body, omitting fields the caller didn't set.

    ``cpus`` / ``memory_mib`` / ``disk_gib`` / ``disk_class`` are omitted
    when ``None`` so the server's ``applyDefaults`` fills them in for
    fresh creates and so they inherit from the snapshot on restore (the
    spec requires omission or exact match on ``snapshot_id`` calls).
    ``disk_mbps`` / ``disk_iops`` / ``net_mbps`` are always sent because
    ``0`` is an explicit "unthrottled" value, distinct from "omitted".

    We don't run this through pydantic ``CreateBoxRequest`` because that
    model copies the spec's ``required: [cpus, memory_mib, ...]`` list,
    which contradicts the server's ``applyDefaults`` + snapshot-inherit
    behaviour. Hand-built dict avoids the mismatch; server-side
    validation still enforces ranges.
    """
    body: dict[str, Any] = {
        "disk_mbps": disk_mbps,
        "disk_iops": disk_iops,
        "net_mbps": net_mbps,
    }
    if cpus is not None:
        body["cpus"] = cpus
    if memory_mib is not None:
        body["memory_mib"] = memory_mib
    if disk_gib is not None:
        body["disk_gib"] = disk_gib
    if disk_class is not None:
        body["disk_class"] = str(disk_class)
    if access_type is not None:
        body["access_type"] = str(access_type)
    if snapshot_id is not None:
        body["snapshot_id"] = snapshot_id
    if ssh_public_key is not None:
        body["ssh_public_key"] = ssh_public_key
    if bootstrap is not None:
        body["bootstrap"] = bootstrap
    if env is not None:
        body["env"] = dict(env)
    if ttl_seconds is not None:
        body["ttl_seconds"] = ttl_seconds
    if name is not None:
        body["name"] = name
    if kind is not None:
        body["kind"] = kind
    if tags is not None:
        body["tags"] = list(tags)
    if web_port is not None:
        # Opt the box into HTTP exposure at its own per-box hostname
        # (https://<box>.<box-edge>/). Mirrors the CLI's --web-port -> spec.Expose
        # wire shape; requires the "exec" boot feature server-side.
        body["expose"] = {"http_port": web_port}
    return body


def raise_for_status(response: httpx.Response) -> None:
    """Map a non-2xx response to the typed exception tree.

    The server returns ``application/problem+json`` (RFC 7807) for
    errors; we parse the body when present and surface the ``detail``
    field as the message. The full body is attached to ``APIError.body``
    so callers can inspect ``type``/``title``/``instance``/etc.
    """
    if response.is_success:
        return
    body: dict[str, Any] | None = None
    detail: str | None = None
    ctype = response.headers.get("content-type", "")
    if "json" in ctype:
        try:
            parsed = response.json()
        except ValueError:
            parsed = None
        if isinstance(parsed, dict):
            body = parsed
            detail = parsed.get("detail") or parsed.get("title")
    request = response.request
    message = detail or (f"hogland {request.method} {request.url}: HTTP {response.status_code}")
    raise from_status(response.status_code, message, body)


def build_sync_client(
    *,
    base_url: str | None,
    token: str | None,
    timeout: httpx.Timeout | float | None,
    transport: httpx.BaseTransport | None,
) -> tuple[httpx.Client, str, str]:
    """Build a sync httpx.Client plus the resolved (base_url, token)."""
    resolved_url = resolve_base_url(base_url)
    resolved_token = resolve_token(token)
    client = httpx.Client(
        base_url=resolved_url,
        headers=default_headers(resolved_token),
        timeout=timeout if timeout is not None else DEFAULT_TIMEOUT,
        transport=transport,
    )
    return client, resolved_url, resolved_token


def build_async_client(
    *,
    base_url: str | None,
    token: str | None,
    timeout: httpx.Timeout | float | None,
    transport: httpx.AsyncBaseTransport | None,
) -> tuple[httpx.AsyncClient, str, str]:
    """Build an async httpx.AsyncClient plus the resolved (base_url, token)."""
    resolved_url = resolve_base_url(base_url)
    resolved_token = resolve_token(token)
    client = httpx.AsyncClient(
        base_url=resolved_url,
        headers=default_headers(resolved_token),
        timeout=timeout if timeout is not None else DEFAULT_TIMEOUT,
        transport=transport,
    )
    return client, resolved_url, resolved_token


__all__ = [
    "DEFAULT_BASE_URL",
    "DEFAULT_TIMEOUT",
    "APIError",
    "build_async_client",
    "build_sync_client",
    "default_headers",
    "raise_for_status",
    "resolve_base_url",
    "resolve_token",
]
