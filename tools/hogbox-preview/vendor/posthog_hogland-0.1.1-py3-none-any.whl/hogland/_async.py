"""Asynchronous hogland client. Mirror of :mod:`hogland._client`.

Same surface, ``async def`` everywhere, returns :class:`AsyncHogbox`
handles. Designed to coexist with the sync client — you can build both
in the same process from the same env vars.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Self

from ._box import AsyncHogbox, _box_path, _snapshots_path
from ._http import _build_create_body, build_async_client, raise_for_status
from ._models import (
    AccessType,
    BoxView,
    DiskClass,
    HogboxList,
    Limits,
    Me,
    SnapshotRecord,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Mapping, Sequence
    from types import TracebackType

    import httpx


class AsyncHogland:
    """Async hogland API client."""

    def __init__(
        self,
        *,
        token: str | None = None,
        base_url: str | None = None,
        timeout: httpx.Timeout | float | None = None,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._http, self._base_url, self._token = build_async_client(
            base_url=base_url,
            token=token,
            timeout=timeout,
            transport=transport,
        )

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self._http.aclose()

    @property
    def base_url(self) -> str:
        return self._base_url

    @property
    def token(self) -> str:
        return self._token

    async def me(self) -> Me:
        resp = await self._http.get("/v1/me")
        raise_for_status(resp)
        return Me.model_validate(resp.json())

    async def limits(self) -> Limits:
        resp = await self._http.get("/v1/limits")
        raise_for_status(resp)
        return Limits.model_validate(resp.json())

    async def create(
        self,
        *,
        cpus: float | None = None,
        memory_mib: int | None = None,
        disk_gib: int | None = None,
        disk_class: DiskClass | str | None = None,
        disk_mbps: int = 0,
        disk_iops: int = 0,
        net_mbps: float = 0,
        access_type: AccessType | str | None = None,
        snapshot_id: str | None = None,
        ssh_public_key: str | None = None,
        bootstrap: str | None = None,
        env: Mapping[str, str] | None = None,
        ttl_seconds: int | None = None,
        name: str | None = None,
        kind: str | None = None,
        tags: Sequence[str] | None = None,
        web_port: int | None = None,
    ) -> AsyncHogbox:
        body = _build_create_body(
            cpus=cpus,
            memory_mib=memory_mib,
            disk_gib=disk_gib,
            disk_class=disk_class,
            disk_mbps=disk_mbps,
            disk_iops=disk_iops,
            net_mbps=net_mbps,
            access_type=access_type,
            snapshot_id=snapshot_id,
            ssh_public_key=ssh_public_key,
            bootstrap=bootstrap,
            env=env,
            ttl_seconds=ttl_seconds,
            name=name,
            kind=kind,
            tags=tags,
            web_port=web_port,
        )
        resp = await self._http.post("/v1/hogboxes", json=body)
        raise_for_status(resp)
        view = BoxView.model_validate(resp.json())
        return AsyncHogbox(view, self)

    async def get(self, box_id: str) -> AsyncHogbox:
        resp = await self._http.get(_box_path(box_id))
        raise_for_status(resp)
        view = BoxView.model_validate(resp.json())
        return AsyncHogbox(view, self)

    async def list(
        self,
        *,
        status: str | None = None,
        kind: str | None = None,
        limit: int | None = None,
        cursor: str | None = None,
    ) -> HogboxList:
        params: dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        if kind is not None:
            params["kind"] = kind
        if limit is not None:
            params["limit"] = limit
        if cursor is not None:
            params["cursor"] = cursor
        resp = await self._http.get("/v1/hogboxes", params=params or None)
        raise_for_status(resp)
        return HogboxList.model_validate(resp.json())

    async def iter_boxes(
        self,
        *,
        status: str | None = None,
        kind: str | None = None,
        page_size: int | None = None,
    ) -> AsyncIterator[BoxView]:
        """Async generator over all matching boxes, following pagination."""
        cursor: str | None = None
        while True:
            page = await self.list(status=status, kind=kind, limit=page_size, cursor=cursor)
            for item in page.items:
                yield item
            if not page.next_cursor:
                return
            cursor = page.next_cursor

    async def snapshot(self, box_id: str) -> SnapshotRecord:
        resp = await self._http.post(_snapshots_path(box_id))
        raise_for_status(resp)
        return SnapshotRecord.model_validate(resp.json())
